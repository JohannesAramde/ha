# django-portfolio-website

GETTING STARTED

1 - Install requirements
  pip install -r requirements.txt
 
2 - Runserver on port 8000

    python manage.py runserver
    
    http://127.0.0.1:8000/
    
3 - Create superuser
    python manage.py createsuperuser
    
![](static/images/personal-blog.jpg)
